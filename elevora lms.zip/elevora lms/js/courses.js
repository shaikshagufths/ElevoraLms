// Seed catalog for the Elevora marketplace.
// Every videoId below was verified live (HTTP 200) via YouTube's oEmbed endpoint.

export function getInitialCourses() {
  return [
    {
      id: 'python-beginners',
      title: 'Python for Beginners',
      subtitle: 'Zero to confident — write clean Python, think like a programmer, and ship your first project.',
      category: 'Code',
      difficulty: 'Beginner',
      instructor: 'Dr. Sara Lin',
      instructorTitle: 'Senior Software Engineer & CS Educator',
      description:
        'Python is the fastest-growing programming language in the world — and the friendliest place to start. In this project-based course you will learn core programming concepts by building small tools, automate boring tasks, and finish with a portfolio-ready project. No prior experience required.',
      thumbnail: null,
      price: 12.99,
      originalPrice: 49.99,
      rating: 4.7,
      reviewCount: 2310,
      students: 84210,
      bestSeller: true,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'July 2026',
      objectives: [
        'Write Python code from absolute scratch with confidence',
        'Master variables, data types, loops, functions and classes',
        'Solve real-world problems with hands-on exercises',
        'Build and ship a final portfolio project'
      ],
      requirements: [
        'No programming experience needed — we start from zero',
        'A computer with internet access is all you need'
      ],
      audience: [
        'Absolute beginners curious about programming',
        'Career switchers looking for a gentle, practical start',
        'Students who learn best by building real projects'
      ],
      reviews: [
        { name: 'Priya S.', rating: 5, date: 'May 2026', text: 'I tried three other courses and this is the first one that actually clicked. Sara explains everything so clearly!' },
        { name: 'Daniel K.', rating: 5, date: 'April 2026', text: 'The final project was the highlight — it pulled together everything I learned. Highly recommended.' },
        { name: 'Marta G.', rating: 4, date: 'March 2026', text: 'Clear pace and great exercises. A few more quizzes would be nice, but overall excellent value.' }
      ],
      lessons: [
        { title: 'Introduction to Python', videoId: '_uQrJ0TkZlc', duration: 512 },
        { title: 'Variables and Data Types', videoId: 'khKv-8q7YmY', duration: 746 },
        { title: 'Control Flow and Loops', videoId: '8ext9G7xspg', duration: 683 },
        { title: 'Functions and Modules', videoId: 'kqtD5dpn9C8', duration: 782 },
        { title: 'OOP and Your First Project', videoId: 'rfscVS0vtbw', duration: 605 }
      ]
    },
    {
      id: 'javascript-mastery',
      title: 'JavaScript Mastery',
      subtitle: 'Go from total beginner to confident developer — variables, the DOM, events and async in one course.',
      category: 'Code',
      difficulty: 'Intermediate',
      instructor: 'Alex Chen',
      instructorTitle: 'Frontend Engineer, 10+ years',
      description:
        'JavaScript powers the modern web. This course takes you through the language itself, then into the browser: manipulating the DOM, handling events, and writing async code with promises. You will leave with the skills to build interactive websites and a strong foundation for React.',
      thumbnail: null,
      price: 15.99,
      originalPrice: 59.99,
      rating: 4.8,
      reviewCount: 3120,
      students: 112400,
      bestSeller: true,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'June 2026',
      objectives: [
        'Write modern JavaScript with clean, idiomatic style',
        'Manipulate the DOM and handle browser events',
        'Master async patterns with promises and fetch',
        'Build interactive, dynamic web pages from scratch'
      ],
      requirements: [
        'Basic HTML knowledge is helpful but not required',
        'A browser and a code editor (free tools only)'
      ],
      audience: [
        'Aspiring frontend developers starting their journey',
        'Students who know a little JS but feel stuck',
        'Designers who want to bring their interfaces to life'
      ],
      reviews: [
        { name: 'Tom R.', rating: 5, date: 'June 2026', text: 'Alex has a gift for making async JavaScript finally make sense. The DOM projects are gold.' },
        { name: 'Aisha M.', rating: 5, date: 'May 2026', text: 'I went from zero to building my own portfolio site. Worth every penny.' },
        { name: 'Ken W.', rating: 4, date: 'April 2026', text: 'Great structure. Pace is quick, so keep a notebook handy.' }
      ],
      lessons: [
        { title: 'JavaScript Fundamentals', videoId: 'PkZNo7MFNFg', duration: 890 },
        { title: 'Variables, Scope and Modern Syntax', videoId: 'W6NZfCO5SIk', duration: 764 },
        { title: 'DOM Manipulation', videoId: '5fb2aPlgoys', duration: 712 },
        { title: 'Async JS and Promises', videoId: 'PoRJizFvM7s', duration: 958 }
      ]
    },
    {
      id: 'react-from-scratch',
      title: 'React from Scratch',
      subtitle: 'Build real applications with components, props, state and hooks — the modern way.',
      category: 'Code',
      difficulty: 'Intermediate',
      instructor: 'Priya Nair',
      instructorTitle: 'Principal Engineer & React Trainer',
      description:
        'React is the world\u2019s most popular UI library. Starting with modern JavaScript fundamentals, you will learn components, JSX, props and state, then level up into hooks and building complete applications. By the end you will have shipped a working React app.',
      thumbnail: null,
      price: 14.99,
      originalPrice: 54.99,
      rating: 4.6,
      reviewCount: 890,
      students: 21300,
      bestSeller: false,
      hotAndNew: true,
      language: 'English',
      lastUpdated: 'July 2026',
      objectives: [
        'Understand modern JavaScript needed for React',
        'Build reusable components with props and state',
        'Use hooks to manage complex application state',
        'Ship a complete, working React application'
      ],
      requirements: [
        'Comfortable with basic JavaScript (variables, functions)',
        'No React experience required'
      ],
      audience: [
        'Frontend developers learning their first framework',
        'JavaScript developers ready to level up their career',
        'Bootcamp grads who want deeper React knowledge'
      ],
      reviews: [
        { name: 'Leo F.', rating: 5, date: 'July 2026', text: 'The hook-by-hook breakdown changed how I think about state. Brilliant course.' },
        { name: 'Nina T.', rating: 4, date: 'June 2026', text: 'Very hands-on. I wish the final project were longer — I wanted more!' }
      ],
      lessons: [
        { title: 'Modern JavaScript Primer', videoId: 'W6NZfCO5SIk', duration: 764 },
        { title: 'Components, JSX and Props', videoId: 'P7t13SGytRk', duration: 1102 },
        { title: 'State, Hooks and Building Apps', videoId: 'DLzxrzFCyOs', duration: 934 }
      ]
    },
    {
      id: 'git-github-workflow',
      title: 'Git & GitHub Workflow',
      subtitle: 'The essential version control toolkit every developer needs — commit, branch, merge, collaborate.',
      category: 'Code',
      difficulty: 'Beginner',
      instructor: 'Marcus Webb',
      instructorTitle: 'DevOps Consultant',
      description:
        'Git is the skill interviewers assume you have. This tight, focused course gets you comfortable with the core workflow: commits, branches, merges, and pushing to GitHub. Perfect as a weekend crash course before your next job application.',
      thumbnail: null,
      price: 9.99,
      originalPrice: 39.99,
      rating: 4.5,
      reviewCount: 1450,
      students: 45200,
      bestSeller: true,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'May 2026',
      objectives: [
        'Track changes with commits and clear messages',
        'Branch, merge and resolve conflicts confidently',
        'Publish and share projects on GitHub',
        'Collaborate with pull requests like a pro'
      ],
      requirements: [
        'Any code editor and a free GitHub account',
        'No prior Git knowledge needed'
      ],
      audience: [
        'New developers who fear version control',
        'Students preparing for their first dev job',
        'Anyone tired of "final_v2_actually_final.js"'
      ],
      reviews: [
        { name: 'Oscar L.', rating: 5, date: 'May 2026', text: 'Short, sharp and exactly what I needed before my internship.' },
        { name: 'Ruby A.', rating: 4, date: 'April 2026', text: 'Conflict resolution finally makes sense to me now!' }
      ],
      lessons: [
        { title: 'Git Basics and First Commits', videoId: 'RBSGKlAvoiM', duration: 786 },
        { title: 'Branching, Merging and GitHub', videoId: 'RGOj5yH7evk', duration: 690 }
      ]
    },
    {
      id: 'node-express-api',
      title: 'Node.js & Express API Development',
      subtitle: 'Build production-style REST APIs with Node, Express and middleware — from server to deployment.',
      category: 'Code',
      difficulty: 'Advanced',
      instructor: 'Daniel Okafor',
      instructorTitle: 'Backend Architect',
      description:
        'The backend is where the real power lives. In this advanced course you will build a complete REST API with Node.js and Express: routing, middleware, error handling, and connecting to a database. You will come out ready to build the backend for any web or mobile app.',
      thumbnail: null,
      price: 16.99,
      originalPrice: 64.99,
      rating: 4.5,
      reviewCount: 980,
      students: 28900,
      bestSeller: false,
      hotAndNew: true,
      language: 'English',
      lastUpdated: 'July 2026',
      objectives: [
        'Set up a Node.js project with Express',
        'Design and build RESTful APIs with clean routes',
        'Handle middleware, validation and errors properly',
        'Connect your API to a database and deploy it'
      ],
      requirements: [
        'Solid understanding of JavaScript fundamentals',
        'Some familiarity with the command line'
      ],
      audience: [
        'Full-stack hopefuls ready to learn the backend',
        'Frontend developers who want to build their own APIs',
        'CS students looking for practical backend skills'
      ],
      reviews: [
        { name: 'Ivan P.', rating: 5, date: 'July 2026', text: 'Finally a course that shows the messy real world — errors, edge cases, deployment. Excellent.' },
        { name: 'Zoe D.', rating: 4, date: 'June 2026', text: 'Dense but worth it. Pause and code along.' }
      ],
      lessons: [
        { title: 'Node.js and Express Setup', videoId: 'QFaFIcGhPoM', duration: 1040 },
        { title: 'Routing and REST APIs', videoId: 'fBNz5xF-Kx4', duration: 986 },
        { title: 'Middleware, Errors and Deployment', videoId: 'Oe421EPjeBE', duration: 1120 }
      ]
    },
    {
      id: 'ui-ux-fundamentals',
      title: 'UI/UX Fundamentals',
      subtitle: 'Master the principles of great design — color, typography, layout and user-centered thinking.',
      category: 'Design',
      difficulty: 'Beginner',
      instructor: 'Marcus Webb',
      instructorTitle: 'Product Designer',
      description:
        'Good design is good business. Learn to think like a UX designer: understand users, structure information, and apply core visual principles like color theory and typography. Perfect for developers, marketers, or anyone who wants interfaces people love.',
      thumbnail: null,
      price: 11.99,
      originalPrice: 44.99,
      rating: 4.6,
      reviewCount: 1980,
      students: 63700,
      bestSeller: true,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'April 2026',
      objectives: [
        'Think like a UX designer and empathize with users',
        'Apply color theory, contrast and typography correctly',
        'Design clean, accessible layouts with confidence',
        'Build a portfolio-ready UI concept'
      ],
      requirements: [
        'No design experience needed',
        'A free design tool (Figma) is used in the course'
      ],
      audience: [
        'Developers who want their apps to look great',
        'Aspiring product and UI/UX designers',
        'Founders designing their own products'
      ],
      reviews: [
        { name: 'Hannah B.', rating: 5, date: 'June 2026', text: 'Color theory alone was worth the price. My interfaces went from meh to gorgeous.' },
        { name: 'Chris M.', rating: 5, date: 'May 2026', text: 'A developer-friendly design course. Highly recommended.' },
        { name: 'Lily J.', rating: 4, date: 'April 2026', text: 'Clear and inspiring. Wish there were downloadable templates.' }
      ],
      lessons: [
        { title: 'What is UI/UX Design?', videoId: '5CxXhyhT6Fc', duration: 610 },
        { title: 'Color Theory Basics', videoId: 'AvgCkHrcj90', duration: 735 },
        { title: 'Typography in Design', videoId: 'QrNi9FmdlxY', duration: 668 }
      ]
    },
    {
      id: 'html-css-bootcamp',
      title: 'HTML & CSS Bootcamp',
      subtitle: 'Build beautiful, responsive websites from scratch — the foundations of the entire web.',
      category: 'Design',
      difficulty: 'Beginner',
      instructor: 'Maya Torres',
      instructorTitle: 'Frontend Mentor & Web Educator',
      description:
        'Every website you have ever loved started with HTML and CSS. This bootcamp takes you from your very first tag to responsive, professional layouts — flexbox, grids, typography, and real projects along the way. The perfect starting point for any web career.',
      thumbnail: null,
      price: 10.99,
      originalPrice: 39.99,
      rating: 4.7,
      reviewCount: 2760,
      students: 98400,
      bestSeller: true,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'May 2026',
      objectives: [
        'Structure pages semantically with modern HTML',
        'Style everything with clean, maintainable CSS',
        'Build responsive layouts with flexbox and grid',
        'Create 3 real projects for your portfolio'
      ],
      requirements: [
        'A browser and a code editor — that is it!',
        'No previous coding experience needed'
      ],
      audience: [
        'Total beginners starting their web journey',
        'Bloggers and creators who want custom sites',
        'Anyone switching careers into web development'
      ],
      reviews: [
        { name: 'Sam E.', rating: 5, date: 'June 2026', text: 'Maya makes CSS feel approachable. I finally understand flexbox and grid.' },
        { name: 'Dina H.', rating: 5, date: 'May 2026', text: 'The projects are perfectly paced. I finished all three in a weekend.' },
        { name: 'Vikram N.', rating: 4, date: 'March 2026', text: 'Solid foundations course — exactly what the title promises.' }
      ],
      lessons: [
        { title: 'HTML from Scratch', videoId: 'pQN-pnXPaVg', duration: 884 },
        { title: 'CSS Styling Fundamentals', videoId: 'qz0aGYrrlhU', duration: 812 },
        { title: 'Flexbox, Grid and Responsive Design', videoId: '1PnVor36_40', duration: 930 }
      ]
    },
    {
      id: 'machine-learning-az',
      title: 'Machine Learning A-Z',
      subtitle: 'Understand the ideas behind AI — neural networks, gradient descent and real ML pipelines.',
      category: 'Science',
      difficulty: 'Advanced',
      instructor: 'Dr. Omar Haddad',
      instructorTitle: 'AI Researcher & Data Scientist',
      description:
        'Demystify machine learning. This course builds your intuition from the ground up: what neural networks are, how they learn through gradient descent, and how modern ML projects are structured end to end. Code-along sessions make the math tangible.',
      thumbnail: null,
      price: 17.99,
      originalPrice: 64.99,
      rating: 4.5,
      reviewCount: 1120,
      students: 38200,
      bestSeller: false,
      hotAndNew: true,
      language: 'English',
      lastUpdated: 'July 2026',
      objectives: [
        'Explain how neural networks actually learn',
        'Understand gradient descent and optimization',
        'Build machine learning pipelines in Python',
        'Know when (and when not) to use ML'
      ],
      requirements: [
        'Basic Python syntax is recommended',
        'High school math — no advanced calculus needed'
      ],
      audience: [
        'Developers curious about the AI hype',
        'Data analysts moving into machine learning',
        'Students preparing for data science careers'
      ],
      reviews: [
        { name: 'Ravi C.', rating: 5, date: 'July 2026', text: 'The neural network visualizations are incredible. Everything finally makes sense.' },
        { name: 'Emily W.', rating: 4, date: 'June 2026', text: 'Great intuition-first approach. Code examples are very clear.' }
      ],
      lessons: [
        { title: 'Machine Learning for Everybody', videoId: 'i_LwzRVP7bg', duration: 1450 },
        { title: 'But What is a Neural Network?', videoId: 'aircAruvnKk', duration: 1250 },
        { title: 'Gradient Descent, How Neural Nets Learn', videoId: 'IHZwWFHWa-w', duration: 1270 }
      ]
    },
    {
      id: 'digital-marketing-101',
      title: 'Digital Marketing 101',
      subtitle: 'SEO, social media, email and analytics — a complete launchpad for modern marketing.',
      category: 'Business',
      difficulty: 'Beginner',
      instructor: 'Lena Novak',
      instructorTitle: 'Growth Marketing Strategist',
      description:
        'Marketing has moved online — and the playbook is public. This course walks you through the full digital marketing stack: SEO, content and social strategy, email funnels, and reading the analytics that matter. Ideal for founders, freelancers and marketing newcomers.',
      thumbnail: null,
      price: 12.99,
      originalPrice: 49.99,
      rating: 4.4,
      reviewCount: 760,
      students: 19300,
      bestSeller: false,
      hotAndNew: true,
      language: 'English',
      lastUpdated: 'June 2026',
      objectives: [
        'Build a complete digital marketing strategy',
        'Rank higher with modern SEO fundamentals',
        'Create email funnels that convert',
        'Measure success with the right analytics'
      ],
      requirements: [
        'No marketing experience needed',
        'Just curiosity and a product or idea to grow'
      ],
      audience: [
        'Founders marketing their first product',
        'Freelancers who want to sell their services online',
        'Students exploring careers in marketing'
      ],
      reviews: [
        { name: 'Grace T.', rating: 5, date: 'June 2026', text: 'Packed with actionable advice. I rebuilt my whole strategy after week one.' },
        { name: 'Mike B.', rating: 4, date: 'May 2026', text: 'Great overview — the SEO section alone is worth it.' }
      ],
      lessons: [
        { title: 'Digital Marketing Foundations', videoId: 'qnBhOVH1QQ8', duration: 1200 },
        { title: 'SEO, Content and Analytics', videoId: 'lm2ym3J4FMw', duration: 1050 }
      ]
    },
    {
      id: 'excel-data-fundamentals',
      title: 'Excel & Data Fundamentals',
      subtitle: 'Become the spreadsheet person — formulas, pivot tables and data analysis everyone will thank you for.',
      category: 'Business',
      difficulty: 'Beginner',
      instructor: 'Lena Novak',
      instructorTitle: 'Analytics Lead',
      description:
        'Excel remains the world\u2019s most used data tool. Learn the formulas, formatting and pivot tables that turn raw spreadsheets into decisions. This course also introduces the data mindset — cleaning, exploring and presenting data — that powers careers everywhere.',
      thumbnail: null,
      price: 10.99,
      originalPrice: 39.99,
      rating: 4.6,
      reviewCount: 1250,
      students: 41800,
      bestSeller: false,
      hotAndNew: false,
      language: 'English',
      lastUpdated: 'March 2026',
      objectives: [
        'Use essential Excel formulas with confidence',
        'Build pivot tables and dynamic dashboards',
        'Clean and structure messy datasets',
        'Present data in charts that tell a story'
      ],
      requirements: [
        'A copy of Excel (or Google Sheets)',
        'No prior spreadsheet experience required'
      ],
      audience: [
        'Office professionals wanting a superpower',
        'Analysts starting their data journey',
        'Students entering business or finance'
      ],
      reviews: [
        { name: 'Fatima K.', rating: 5, date: 'May 2026', text: 'I saved hours a week after learning pivot tables. Instant ROI.' },
        { name: 'Josh D.', rating: 4, date: 'April 2026', text: 'Clear, practical, and genuinely fun. More real datasets please!' }
      ],
      lessons: [
        { title: 'Excel Fundamentals and Formulas', videoId: 'Vl0H-qTclOg', duration: 980 },
        { title: 'Data Analysis and Visualization', videoId: 'ua-CiDNNj30', duration: 900 }
      ]
    }
  ];
}
