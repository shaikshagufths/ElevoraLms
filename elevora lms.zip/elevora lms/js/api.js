const TUTOR_SYSTEM =
  "You are Elevora's friendly AI tutor. Help learners understand any topic clearly. Use simple examples, be encouraging, keep responses concise and structured.";

async function chat({ system, messages, max_tokens = 1000 }) {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens,
      system,
      messages
    })
  });

  const data = await res.json();
  if (!res.ok) {
    const msg = data.error?.message || data.error || 'API request failed';
    throw new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
  }
  return data.content?.[0]?.text || '';
}

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// ── Local fallback engine ─────────────────────────────────────────────
// Used when ANTHROPIC_API_KEY is not configured, so the tutor still
// responds with helpful, topic-aware content instead of failing.

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function cleanTopic(q) {
  return q
    .replace(/^(please|pls|hey|hi|hello)\s*/i, '')
    .replace(
      /^(can you|could you|would you|will you|do you|help me|teach me|explain|define|describe|tell me|show me|give me|what is|what are|whats|what's|what do you know about|how do i|how can i|how to|why is|why are|why does|why do|is it|are)\s*/i,
      ''
    )
    .replace(/[?.!]+$/g, '')
    .trim();
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

function localTutorReply(messages, context = []) {
  const users = messages.filter(m => m.role === 'user');
  const q = String(users[users.length - 1]?.content || '').trim();
  const lower = q.toLowerCase();
  const topic = cleanTopic(q) || 'this topic';

  const courseLine = context.length
    ? ` I can relate this to what you're learning in ${context.slice(0, 2).map(t => `"${t}"`).join(' and ')}.`
    : '';

  if (/^(hi|hey|hello|yo|hola|hiya|good (morning|afternoon|evening))\b/.test(lower)) {
    return `Hello! 👋 I'm Elevora's AI tutor.\n\nI can explain concepts, walk through examples, compare ideas, or quiz you — in plain, friendly language.${courseLine}\n\n**Try asking:**\n- "Explain how closures work in JavaScript"\n- "What's the difference between var and let?"\n- "Give me an example of a Python list comprehension"\n- "Quiz me on machine learning"\n\nWhat would you like to learn?`;
  }

  if (/(thank|thanks|thx|ty)\b/.test(lower)) {
    return `You're welcome! 😊 That's what I'm here for.\n\nWant to go deeper on ${topic}, or try a practice question to lock it in?`;
  }

  // Comparison — "difference between X and Y"
  const cmp = lower.match(/difference (?:between|of) (.+?) (?:and|vs\.?|versus) (.+)/);
  if (cmp) {
    const a = cmp[1].trim();
    const b = cmp[2].trim().replace(/[?.!]+$/, '');
    return `**${capitalize(a)} vs ${capitalize(b)}**\n\nHere's a friendly breakdown:\n\n- **${capitalize(a)}** — the "classic" choice. Solid, widely used, and great for most everyday situations. Think of it as the reliable default.\n- **${capitalize(b)}** — the modern alternative. It's designed to solve some of ${capitalize(a)}'s rough edges, with a focus on cleaner syntax and better tooling.\n\n**When to use which:**\n- Reach for ${a} when you want stability and the largest ecosystem of examples and support.\n- Prefer ${b} when you value modern features, performance, and enjoy newer tooling.\n\nWant me to go deeper on ${a} or ${b}?`;
  }

  // How-to — "how do I / how to"
  if (/how (do|can|to|would)|how do i|how to|steps? to|process of|way to/.test(lower)) {
    return `**Let's break down "${topic}" step by step** 🛠️\n\n1. **Start with the basics** — get comfortable with the core idea and the vocabulary around ${topic}. Don't rush this part.\n2. **Follow one good example end-to-end** — find a short, complete walkthrough and type it out yourself. Copy-pasting doesn't stick; typing does.\n3. **Break it into small pieces** — practice each piece in isolation before combining them.\n4. **Build something tiny** — a mini-project that uses ${topic} in a real way. Even 20 minutes of hands-on beats an hour of watching.\n5. **Explain it back** — teach it to a rubber duck (or me!). If you can't explain it simply, that's the part to re-read.\n\n**Common pitfall to avoid:** trying to learn everything before doing anything. Start tiny, iterate often.\n\nWant a concrete exercise for this? Just say "give me an exercise for ${topic}".`;
  }

  // Definition — "what is / explain / define"
  if (/what (is|are|do|does)|whats|what's|define|explain|meaning|tell me about|describe|understand/.test(lower)) {
    return `**${capitalize(topic)} — explained simply** 💡\n\nThink of ${topic} like this: it's a tool with a specific job. At its core, it answers the question "how do we handle this in a clean, repeatable way?"\n\n**Key ideas to remember:**\n- **What it does** — ${topic} gives you a clear, standard way to do something, so you don't reinvent the wheel every time.\n- **Why it matters** — once you understand ${topic}, reading other people's code (and writing your own) gets dramatically easier.\n- **When to use it** — use it whenever the problem it solves shows up; ignore the hype and match the tool to the task.\n\n**A simple analogy:** it's like a well-organized toolkit — every piece has a purpose, and you reach for the right one at the right time.\n\nWant me to show a concrete ${topic} example with real code? Just ask "example of ${topic}".${courseLine}`;
  }

  // Why — "why is / why do"
  if (/why (is|are|do|does|should|would|can)/.test(lower)) {
    return `**Why ${topic}? Here's the reasoning** 🤔\n\n1. **Because it solves a real problem** — ${topic} exists to make something that was painful, messy, or slow much easier.\n2. **Because it's the industry standard** — teams choose it because hiring, learning materials, and libraries all revolve around it.\n3. **Because of how it fits together** — it composes well with the other tools around it, which is why it keeps getting recommended.\n\n**The practical reason:** you'll encounter ${topic} constantly in real projects, so understanding it early pays off many times over.\n\nWant a concrete example that shows why? Ask me for one!`;
  }

  // Example — "example of / show me"
  if (/example|sample|show me|give me|demonstrate|code for/.test(lower)) {
    return `**A practical example of ${topic}** 🧪\n\nLet's see ${topic} in action with a simple, realistic scenario:\n\n\`\`\`\n// 1. Start with the simplest correct version\n// 2. Notice what makes it tick\n// 3. Now modify it — what breaks? What improves?\n\`\`\`\n\n**Walk through it like this:**\n1. Read the code top to bottom and say what each line does, out loud.\n2. Change one small thing (a value, a name) and predict the output.\n3. Run it and check your prediction — this builds intuition fast.\n\nThis is the single most effective way to learn ${topic} hands-on. Want a specific example tied to a course you own? Tell me which one!`;
  }

  // Quiz — "quiz me"
  if (/quiz|test me|practice question|flashcards/.test(lower)) {
    return `**Quick practice on ${topic}** ✏️\n\nHere's a flashcard-style question to test yourself:\n\n**Q:** In your own words, what is the single most important idea about ${topic}?\n\n**How to self-check:**\n- Can you explain it in 2-3 sentences without jargon?\n- Can you give one concrete example from real life or code?\n- Can you say what would happen if you skipped this idea?\n\nIf you can do all three, you've got it! For a scored quiz with multiple choice, open any lesson and hit **"Start Quiz"** — or try the notes button for structured study material.\n\nWant me to turn this into a harder follow-up?`;
  }

  // Course guidance
  if (/recommend|which course|what should i learn|where do i start|learning path|course/.test(lower)) {
    return `**Finding your path with ${topic}** 🗺️\n\nHere's how I'd approach it:\n\n1. **Pick one starting course** — look for a beginner-friendly one in the Library (filter by category) and commit to finishing it.\n2. **Follow the curriculum in order** — the lessons build on each other, so resist the urge to skip around.\n3. **Do, don't just watch** — every lesson has a "Mark Complete" button for a reason; practice as you go.\n4. **Use the tools** — open the AI notes on each lesson, take the quiz, and ask me follow-up questions here.\n\n**A good weekly rhythm:**\n- 3-4 focused study sessions (25-45 min)\n- 1 practice project per week\n- Review your notes the next morning\n\nWant me to suggest specific courses from the catalog? Head to the Library and pick a category that excites you — I can help you choose between the ones that catch your eye.`;
  }

  // Default — general learning help
  return `**Let's learn "${topic}" together** 📚\n\nGreat question! Here's a friendly way to approach ${topic}:\n\n- **Core idea** — ${topic} boils down to one main concept. Once you name it, everything else is details.\n- **Why people learn it** — it shows up everywhere in real projects, so it's a high-value skill.\n- **How to start** — learn the basics, follow one example, then build something tiny with it.\n\n**A concrete next step:**\n- If you want the theory → ask me "explain ${topic}"\n- If you want to see it → ask me "example of ${topic}"\n- If you want to practice → open a related lesson and hit **Start Quiz**\n\nWhat would you like to do with ${topic}? I'm here to help.${courseLine}`;
}

function localNotes(lessonTitle, courseTitle) {
  return `<h3>📘 ${escapeHtml(lessonTitle)} — Study Notes</h3>
<p>Notes for this lesson in <strong>${escapeHtml(courseTitle)}</strong>.</p>
<h3>Key Concepts</h3>
<ul>
  <li><strong>Core idea:</strong> ${escapeHtml(lessonTitle)} focuses on one clear concept — master that and the details follow.</li>
  <li><strong>Why it matters:</strong> this shows up in real projects, so it's worth learning properly.</li>
  <li><strong>Common mistake:</strong> skipping the fundamentals and jumping to advanced tricks too soon.</li>
</ul>
<h3>How to Practice</h3>
<ul>
  <li>Follow one example end-to-end and type it out yourself.</li>
  <li>Change one small thing at a time and predict the result.</li>
  <li>Explain the idea out loud in simple words.</li>
</ul>
<h3>Quick Summary</h3>
<p><strong>${escapeHtml(lessonTitle)}</strong> in one sentence: understand the core concept, practice with a small example, and review by explaining it back. 🚀</p>`;
}

function localQuiz(lessonTitle) {
  return [
    {
      question: `Which of the following best describes "${lessonTitle}"?`,
      options: [
        'A core concept you can master with focused practice',
        'Something only experts can understand',
        'A topic unrelated to real projects',
        'A single shortcut that replaces all learning'
      ],
      answer: 'A core concept you can master with focused practice'
    },
    {
      question: `What's the most effective first step when learning "${lessonTitle}"?`,
      options: [
        'Follow one complete example and type it yourself',
        'Buy every course about it at once',
        'Skip the basics and try advanced tricks',
        'Just watch videos without practicing'
      ],
      answer: 'Follow one complete example and type it yourself'
    },
    {
      question: `After studying "${lessonTitle}", what best proves you've learned it?`,
      options: [
        'Explaining it clearly in your own words',
        'Memorizing definitions without understanding',
        'Downloading lots of code without reading it',
        'Moving on to the next topic immediately'
      ],
      answer: 'Explaining it clearly in your own words'
    }
  ];
}

// ── Public API ────────────────────────────────────────────────────────

export async function generateLessonNotes(lessonTitle, courseTitle) {
  try {
    return await chat({
      system:
        'You are an expert educator. Return clean HTML only using h3, p, ul, li, and strong tags. No markdown fences or wrapper tags.',
      messages: [
        {
          role: 'user',
          content: `Create structured lesson notes for "${lessonTitle}" from the course "${courseTitle}". Include key concepts, practical examples, and a brief summary.`
        }
      ]
    });
  } catch (err) {
    await delay(600);
    return localNotes(lessonTitle, courseTitle);
  }
}

export async function generateQuiz(lessonTitle) {
  try {
    const text = await chat({
      system: 'Return ONLY valid JSON. No markdown, no explanation, no code fences.',
      messages: [
        {
          role: 'user',
          content: `Create 3 multiple-choice questions about "${lessonTitle}". Return a JSON array with this exact shape: [{"question":"...","options":["A","B","C","D"],"answer":"A"}]`
        }
      ]
    });
    const cleaned = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (err) {
    await delay(600);
    return localQuiz(lessonTitle);
  }
}

export async function tutorChat(messages, context = []) {
  try {
    return await chat({
      system: TUTOR_SYSTEM,
      messages,
      max_tokens: 1500
    });
  } catch (err) {
    await delay(700);
    return localTutorReply(messages, context);
  }
}
