export function extractVideoId(url) {
  if (!url) return null;
  const match = url.match(/(?:v=|youtu\.be\/|embed\/)([^&?/]+)/);
  return match ? match[1] : null;
}

export function getThumbnail(videoId) {
  return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
}

export function getEmbedUrl(videoId) {
  return `https://www.youtube.com/embed/${videoId}`;
}

export function gradientFallback(title) {
  const initials = (title || 'C')
    .split(' ')
    .map(w => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  const hues = [260, 200, 320, 40, 160];
  const hue = hues[(title?.length || 0) % hues.length];
  return {
    style: `background: linear-gradient(135deg, hsl(${hue}, 55%, 42%), hsl(${hue + 35}, 65%, 58%));`,
    initials
  };
}
