const routes = [];
let currentPath = '';
let onRouteChange = null;

export function registerRoute(pattern, handler) {
  routes.push({ pattern, handler });
}

export function setRouteChangeCallback(cb) {
  onRouteChange = cb;
}

export function navigate(path, push = true) {
  if (push) history.pushState(null, '', path);
  render(path);
}

function matchRoute(pathname) {
  for (const { pattern, handler } of routes) {
    if (pattern === pathname) {
      return { handler, params: {} };
    }
    const paramNames = [];
    const regexStr = pattern.replace(/:([^/]+)/g, (_, name) => {
      paramNames.push(name);
      return '([^/]+)';
    });
    const regex = new RegExp(`^${regexStr}$`);
    const match = pathname.match(regex);
    if (match) {
      const params = {};
      paramNames.forEach((name, i) => {
        params[name] = match[i + 1];
      });
      return { handler, params };
    }
  }
  return null;
}

function render(path) {
  const matched = matchRoute(path) || matchRoute('/');
  const app = document.getElementById('app');
  if (!app || !matched) return;

  app.style.opacity = '0';
  setTimeout(() => {
    currentPath = path;
    app.innerHTML = matched.handler(matched.params) || '';
    updateNavActive(path);
    if (onRouteChange) onRouteChange(path, matched.params);
    app.style.opacity = '1';
  }, 200);
}

function updateNavActive(path) {
  document.querySelectorAll('[data-nav]').forEach(el => {
    const navPath = el.dataset.nav;
    let active = false;
    if (navPath === '/') {
      active = path === '/';
    } else if (navPath === '/library') {
      active = path === '/library' || path.startsWith('/course');
    } else {
      active = path === navPath || path.startsWith(navPath + '/');
    }
    el.classList.toggle('active', active);
  });
}

export function getCurrentPath() {
  return currentPath;
}

export function initRouter() {
  window.addEventListener('popstate', () => render(location.pathname));
  render(location.pathname || '/');
}
