import { getInitialCourses } from './courses.js';
import { registerRoute, navigate, initRouter, setRouteChangeCallback } from './router.js';
import { extractVideoId, getThumbnail, getEmbedUrl, gradientFallback } from './youtube.js';
import * as api from './api.js';

const STORAGE_KEY = 'elevora_state_v2';

const state = {
  user: { name: 'Alex', streak: 5, hoursLearned: 12, memberSince: 'June 2025' },
  cart: [],
  wishlist: [],
  orders: [],
  purchases: [],
  completedLessons: {},
  lastOpened: null,
  courses: [],
  tutorMessages: [],
  libraryFilter: 'All',
  librarySearch: '',
  librarySort: 'Most popular'
};

// ── Persistence ──

function loadState() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      Object.assign(state, JSON.parse(saved));
    } catch (e) { /* ignore corrupt state */ }
  } else {
    // Migrate from the previous version of the app.
    try {
      const legacy = localStorage.getItem('elevora_state');
      if (legacy) {
        const parsed = JSON.parse(legacy);
        if (Array.isArray(parsed.enrolledCourses) && !parsed.purchases) {
          parsed.purchases = parsed.enrolledCourses;
        }
        Object.assign(state, parsed);
        localStorage.removeItem('elevora_state');
      }
    } catch (e) { /* ignore */ }
  }
  state.cart = Array.isArray(state.cart) ? state.cart : [];
  state.wishlist = Array.isArray(state.wishlist) ? state.wishlist : [];
  state.orders = Array.isArray(state.orders) ? state.orders : [];
  state.purchases = Array.isArray(state.purchases) ? state.purchases : [];
  state.librarySort = state.librarySort || 'Most popular';
  const initial = getInitialCourses();
  const userAdded = (state.courses || []).filter(c => c.userAdded);
  state.courses = [...initial, ...userAdded];
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    user: state.user,
    cart: state.cart,
    wishlist: state.wishlist,
    orders: state.orders,
    purchases: state.purchases,
    completedLessons: state.completedLessons,
    lastOpened: state.lastOpened,
    courses: state.courses.filter(c => c.userAdded),
    tutorMessages: state.tutorMessages,
    libraryFilter: state.libraryFilter,
    librarySearch: state.librarySearch,
    librarySort: state.librarySort
  }));
}

// ── Helpers ──

function getCourse(id) {
  return state.courses.find(c => c.id === id);
}

function isPurchased(courseId) {
  return state.purchases.includes(courseId);
}

function inCart(courseId) {
  return state.cart.includes(courseId);
}

function inWishlist(courseId) {
  return state.wishlist.includes(courseId);
}

function addToCart(courseId) {
  const course = getCourse(courseId);
  if (!course) return;
  if (isPurchased(courseId)) {
    showToast('You already own this course', 'error');
    return;
  }
  if (inCart(courseId)) {
    showToast('Already in your cart');
    return;
  }
  state.cart.push(courseId);
  saveState();
  updateCartBadge();
  showToast(`Added to cart — ${course.title}`);
}

function buyNow(courseId) {
  const course = getCourse(courseId);
  if (!course) return;
  if (isPurchased(courseId)) {
    navigate(`/course/${courseId}`);
    return;
  }
  if (!inCart(courseId)) {
    state.cart.push(courseId);
    saveState();
  }
  updateCartBadge();
  navigate('/checkout');
}

function toggleWishlist(courseId) {
  const idx = state.wishlist.indexOf(courseId);
  if (idx >= 0) {
    state.wishlist.splice(idx, 1);
    showToast('Removed from wishlist');
  } else {
    state.wishlist.push(courseId);
    showToast('Added to wishlist ❤');
  }
  saveState();
}

function formatPrice(p) {
  if (p === undefined || p === null) p = 0;
  if (p <= 0) return 'Free';
  return '$' + (Number.isInteger(p) ? p.toString() : p.toFixed(2));
}

function discountPct(course) {
  if (!course.originalPrice || course.originalPrice <= course.price) return 0;
  return Math.round((1 - course.price / course.originalPrice) * 100);
}

function courseTotalDuration(course) {
  return (course.lessons || []).reduce((sum, l) => sum + (l.duration || 0), 0);
}

function fmtClock(secs) {
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function fmtTotal(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.round((secs % 3600) / 60);
  return h ? `${h}h ${m}m` : `${m}m`;
}

function cartSubtotal() {
  return state.cart.reduce((sum, id) => sum + (getCourse(id)?.price || 0), 0);
}

function cartOriginalTotal() {
  return state.cart.reduce((sum, id) => sum + (getCourse(id)?.originalPrice || getCourse(id)?.price || 0), 0);
}

function cartSavings() {
  return Math.max(0, cartOriginalTotal() - cartSubtotal());
}

function ratingStars(rating) {
  const pct = Math.max(0, Math.min(100, (rating / 5) * 100));
  return `<span class="stars" aria-hidden="true">
    <span class="stars-bg">★★★★★</span>
    <span class="stars-fill" style="width:${pct}%">★★★★★</span>
  </span>`;
}

function ratingRow(rating, reviewCount) {
  if (!rating) return '';
  return `<div class="course-rating">
    <span class="rating-num">${rating.toFixed(1)}</span>${ratingStars(rating)}
    ${reviewCount ? `<span class="rating-count">(${reviewCount.toLocaleString()})</span>` : ''}
  </div>`;
}

function priceRow(course, big = false) {
  const free = course.price <= 0;
  return `<div class="course-price-row ${big ? 'purchase-price' : ''}">
    <span class="${free ? 'price-free' : 'price'}">${formatPrice(course.price)}</span>
    ${course.originalPrice > course.price ? `<span class="original-price">${formatPrice(course.originalPrice)}</span>` : ''}
    ${discountPct(course) ? `<span class="discount-pct">${discountPct(course)}% off</span>` : ''}
  </div>`;
}

function getCourseThumbnail(course) {
  if (course.thumbnail) return course.thumbnail;
  const firstVideo = course.lessons[0]?.videoId;
  if (firstVideo) return getThumbnail(firstVideo);
  return null;
}

function renderThumbnail(course, className = 'course-thumb') {
  const url = getCourseThumbnail(course);
  if (url) {
    return `<div class="${className}"><img src="${url}" alt="${escapeHtml(course.title)}" loading="lazy" /></div>`;
  }
  const fb = gradientFallback(course.title);
  return `<div class="${className}"><div class="course-thumb-gradient" style="${fb.style}">${fb.initials}</div></div>`;
}

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Render the tutor's markdown-ish replies (bold, lists, headings, code) as safe HTML.
function formatAiContent(text) {
  const esc = escapeHtml(text);
  const lines = esc.split('\n');
  let html = '';
  let inUl = false;
  let inOl = false;
  let inCode = false;
  const closeLists = () => {
    if (inUl) { html += '</ul>'; inUl = false; }
    if (inOl) { html += '</ol>'; inOl = false; }
  };
  const bold = s => s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  for (const raw of lines) {
    const line = raw.trim();
    if (line.startsWith('```')) {
      closeLists();
      if (!inCode) { html += '<pre><code>'; inCode = true; } else { html += '</code></pre>'; inCode = false; }
      continue;
    }
    if (inCode) { html += line + '\n'; continue; }
    if (!line) { closeLists(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)/);
    if (heading) {
      closeLists();
      html += `<h4>${bold(heading[2])}</h4>`;
    } else if (/^[-*]\s+/.test(line)) {
      if (!inUl) { closeLists(); html += '<ul>'; inUl = true; }
      html += `<li>${bold(line.replace(/^[-*]\s+/, ''))}</li>`;
    } else if (/^\d+[.)]\s+/.test(line)) {
      if (!inOl) { closeLists(); html += '<ol>'; inOl = true; }
      html += `<li>${bold(line.replace(/^\d+[.)]\s+/, ''))}</li>`;
    } else {
      closeLists();
      html += `<p>${bold(line)}</p>`;
    }
  }
  closeLists();
  if (inCode) html += '</code></pre>';
  return html;
}

function updateCartBadge() {
  const el = document.getElementById('cart-count');
  if (el) el.textContent = state.cart.length;
}

function closePreviewModal() {
  const modal = document.getElementById('preview-modal');
  if (!modal || modal.hidden) return;
  modal.hidden = true;
  document.body.style.overflow = '';
  document.getElementById('preview-frame').src = '';
}

function showSkeleton(container, lines = 4) {
  container.innerHTML = Array.from({ length: lines }, (_, i) =>
    `<div class="skeleton skeleton-line ${i % 2 ? 'short' : 'medium'}"></div>`
  ).join('');
}

function courseCard(course) {
  const owned = isPurchased(course.id);
  return `
    <div class="course-card" data-goto="/course/${course.id}">
      <div class="course-thumb-wrap">
        ${renderThumbnail(course, 'course-thumb')}
        ${course.bestSeller ? '<div class="bestseller-badge">Best seller</div>' : ''}
        ${course.hotAndNew && !course.bestSeller ? '<div class="new-badge">New</div>' : ''}
        ${owned ? '<div class="owned-badge">✓ You own this course</div>' : ''}
        <button class="wish-btn ${inWishlist(course.id) ? 'active' : ''}" data-wishlist="${course.id}" title="${inWishlist(course.id) ? 'Remove from wishlist' : 'Save to wishlist'}" aria-label="Toggle wishlist">♥</button>
      </div>
      <div class="course-card-body">
        <h3 class="course-card-title">${escapeHtml(course.title)}</h3>
        <div class="course-card-instructor">${escapeHtml(course.instructor)}</div>
        ${ratingRow(course.rating, course.reviewCount)}
        ${priceRow(course)}
        <div class="course-card-stats">${fmtTotal(courseTotalDuration(course))} · ${course.lessons.length} lectures · ${course.difficulty}</div>
      </div>
    </div>`;
}

// ── Home / marketplace ──

function renderHome() {
  const bestSellers = state.courses.filter(c => c.bestSeller);
  const hotNew = state.courses.filter(c => c.hotAndNew);
  const topRated = [...state.courses].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 4);

  const catMeta = {
    Code: { icon: '💻', blurb: 'Programming & development' },
    Design: { icon: '🎨', blurb: 'UI/UX & creative skills' },
    Business: { icon: '📈', blurb: 'Marketing & entrepreneurship' },
    Science: { icon: '🧪', blurb: 'Data, AI & machine learning' }
  };
  const catTiles = Object.keys(catMeta).map(cat => {
    const count = state.courses.filter(c => c.category === cat).length;
    if (!count) return '';
    return `
      <div class="category-tile" data-category="${cat}">
        <span class="cat-icon">${catMeta[cat].icon}</span>
        <div>
          <b>${cat}</b>
          <span>${count} course${count > 1 ? 's' : ''} · ${catMeta[cat].blurb}</span>
        </div>
        <span class="cat-arrow">→</span>
      </div>`;
  }).join('');

  const continueHtml = state.lastOpened && isPurchased(state.lastOpened.courseId) && getCourse(state.lastOpened.courseId)
    ? `<section class="home-section">
        <div class="continue-card">
          <div>
            <h2>Continue Learning</h2>
            <p>${escapeHtml(getCourse(state.lastOpened.courseId).title)} — pick up where you left off</p>
          </div>
          <a href="/course/${state.lastOpened.courseId}/lesson/${state.lastOpened.lessonIndex}" class="btn" data-link>Resume →</a>
        </div>
      </section>`
    : '';

  return `
    <section class="hero">
      <div class="hero-inner">
        <h1>Learn what moves you forward</h1>
        <p>Expert-led video courses that fit your pace — start fresh, switch paths, or go deeper in your field.</p>
        <div class="hero-search">
          <input id="home-search" type="text" placeholder="What skill do you want to build?" autocomplete="off" />
          <button class="btn" id="home-search-btn">Search</button>
        </div>
        <div class="hero-chips">
          <span>Popular:</span>
          <button class="chip" data-search="JavaScript">JavaScript</button>
          <button class="chip" data-search="Python">Python</button>
          <button class="chip" data-search="React">React</button>
          <button class="chip" data-search="Machine Learning">Machine Learning</button>
          <button class="chip" data-search="Excel">Excel</button>
        </div>
      </div>
    </section>

    <section class="home-stats">
      <div class="home-stat"><b>120,000+</b><span>Courses taught</span></div>
      <div class="home-stat"><b>${state.courses.length}</b><span>Live in our catalog</span></div>
      <div class="home-stat"><b>4.6★</b><span>Average rating</span></div>
      <div class="home-stat"><b>Lifetime</b><span>Access to what you buy</span></div>
    </section>

    ${continueHtml}

    <section class="home-section">
      <h2>Courses for every ambition</h2>
      <p>Practical, hands-on training taught by people who do the work every day.</p>
      <div class="category-tiles">${catTiles}</div>
    </section>

    <section class="home-section">
      <h2>Most loved by learners</h2>
      <p>Top picks that learners keep coming back to.</p>
      <div class="course-grid">${bestSellers.map(courseCard).join('') || '<div class="empty-state"><p>No courses yet.</p></div>'}</div>
    </section>

    <section class="home-section">
      <h2>Fresh &amp; trending</h2>
      <p>Just-published courses the community is talking about.</p>
      <div class="course-grid">${hotNew.map(courseCard).join('') || '<div class="empty-state"><p>Nothing here yet.</p></div>'}</div>
    </section>

    <section class="home-section">
      <h2>Top rated</h2>
      <p>See what learners rate the highest across the catalog.</p>
      <div class="course-grid">${topRated.map(courseCard).join('')}</div>
    </section>

    <section class="teach-banner">
      <div>
        <h3>Come teach with us</h3>
        <p>Turn what you know into a course the world can buy — our tools make it easy.</p>
      </div>
      <a href="/add-course" class="btn btn-primary" data-link>Start teaching →</a>
    </section>`;
}

// ── Library ──

function renderLibrary() {
  const categories = ['All', 'Code', 'Design', 'Business', 'Science'];
  const tabs = categories.map(cat =>
    `<button class="filter-tab ${state.libraryFilter === cat ? 'active' : ''}" data-filter="${cat}">${cat}</button>`
  ).join('');

  const sorters = {
    'Most popular': (a, b) => (b.students || 0) - (a.students || 0),
    'Highest rated': (a, b) => (b.rating || 0) - (a.rating || 0),
    'Price: Low to High': (a, b) => a.price - b.price,
    'Price: High to Low': (a, b) => b.price - a.price
  };
  const sortOptions = Object.keys(sorters).map(s =>
    `<option value="${s}" ${state.librarySort === s ? 'selected' : ''}>${s}</option>`
  ).join('');

  const filtered = state.courses
    .filter(c => {
      const matchCat = state.libraryFilter === 'All' || c.category === state.libraryFilter;
      const matchSearch = !state.librarySearch || c.title.toLowerCase().includes(state.librarySearch.toLowerCase());
      return matchCat && matchSearch;
    })
    .sort(sorters[state.librarySort] || sorters['Most popular']);

  return `
    <div class="page-header">
      <h1>Course Library</h1>
      <p>${state.courses.length} courses · browse, compare and pick your next skill</p>
    </div>
    <div class="search-bar">
      <input type="text" class="search-input" id="library-search" placeholder="Search courses…" value="${escapeHtml(state.librarySearch)}" />
      <select class="sort-select" id="library-sort">
        ${sortOptions}
      </select>
    </div>
    <div class="filter-tabs">${tabs}</div>
    <div class="course-grid">${filtered.map(courseCard).join('') || '<div class="empty-state"><p>No courses found.</p></div>'}</div>`;
}

// ── Course landing ──

function curriculumSections(course) {
  const chunkSize = Math.max(3, Math.ceil(course.lessons.length / 3));
  const names = ['Getting Started', 'Core Concepts', 'Hands-On Practice', 'Advanced Topics', 'Putting It All Together', 'Final Project'];
  const sections = [];
  for (let i = 0; i < course.lessons.length; i += chunkSize) {
    sections.push({
      name: names[sections.length] || `Section ${sections.length + 1}`,
      startIndex: i,
      lessons: course.lessons.slice(i, i + chunkSize)
    });
  }
  return sections;
}

function renderCurriculum(course) {
  const sections = curriculumSections(course);
  return sections.map((sec, si) => `
    <div class="module ${si === 0 ? 'open' : ''}">
      <div class="module-header" data-toggle-module>
        <span>Section ${si + 1}: ${sec.name}</span>
        <span class="module-meta">${fmtTotal(sec.lessons.reduce((s, l) => s + (l.duration || 0), 0))} · ${sec.lessons.length} lectures</span>
        <span class="module-chevron">▼</span>
      </div>
      <div class="module-lessons">
        ${sec.lessons.map((lesson, i) => {
          const idx = sec.startIndex + i;
          return `
            <div class="lesson-item" data-goto="/course/${course.id}/lesson/${idx}">
              <span class="lesson-check ${isLessonComplete(course.id, idx) ? 'done' : ''}">${isLessonComplete(course.id, idx) ? '✓' : ''}</span>
              <span class="lesson-title">${escapeHtml(lesson.title)}</span>
              <span class="lesson-duration">${fmtClock(lesson.duration || 0)}</span>
            </div>`;
        }).join('')}
      </div>
    </div>`).join('');
}

function renderReviews(course) {
  if (!course.reviews || !course.reviews.length) return '<p class="text-muted">No reviews yet — be the first!</p>';
  return course.reviews.map(r => `
    <div class="review">
      <div class="review-head">
        <div class="review-avatar">${r.name[0]}</div>
        <div>
          <div class="review-name">${escapeHtml(r.name)}</div>
          <div class="review-date">${r.date} · ${r.rating}.0</div>
        </div>
      </div>
      <div class="review-text">${escapeHtml(r.text)}</div>
    </div>`).join('');
}

function renderCourseDetail({ id }) {
  const course = getCourse(id);
  if (!course) return `<div class="empty-state"><p>Course not found.</p><a href="/library" class="btn btn-primary" data-link>Back to Library</a></div>`;

  const owned = isPurchased(id);
  const inWish = inWishlist(id);
  const thumb = getCourseThumbnail(course);
  const heroContent = thumb
    ? `<img src="${thumb}" alt="${escapeHtml(course.title)}" />`
    : `<div class="course-thumb-gradient" style="${gradientFallback(course.title).style}">${gradientFallback(course.title).initials}</div>`;

  const previewVideoId = course.lessons[0]?.videoId;
  const previewEmbed = previewVideoId ? getEmbedUrl(previewVideoId) : null;

  const objectivesHtml = (course.objectives || []).map(o => `<div class="objective-item">${escapeHtml(o)}</div>`).join('');
  const requirementsHtml = (course.requirements || []).map(r => `<li>${escapeHtml(r)}</li>`).join('');
  const includes = [
    { icon: '🎬', text: `${course.lessons.length} lectures · ${fmtTotal(courseTotalDuration(course))} of video` },
    { icon: '♾️', text: 'Full lifetime access' },
    { icon: '📱', text: 'Access on mobile and TV' },
    { icon: '🏅', text: 'Certificate of completion' },
    { icon: '🧑‍🏫', text: 'Direct Q&A with the instructor' }
  ];
  const includesHtml = includes.map(i => `<li><span>${i.icon}</span>${i.text}</li>`).join('');

  const actionHtml = owned
    ? `<a href="/course/${id}/lesson/${state.lastOpened?.courseId === id ? state.lastOpened.lessonIndex : 0}" class="btn btn-primary" data-link>Go to Course →</a>
       <a href="/my-courses" class="btn btn-outline-dark" data-link>My Learning</a>`
    : course.price <= 0
      ? `<button class="btn btn-primary" data-enroll="${id}">Enroll Now</button>`
      : `<button class="btn btn-primary" data-add-cart="${id}">${inCart(id) ? '✓ In Cart' : 'Add to Cart'}</button>
         <button class="btn btn-outline-dark" data-buy-now="${id}">Buy Now</button>`;

  return `
    <div class="course-band">
      <div class="breadcrumb">${course.category} › ${course.difficulty} › ${escapeHtml(course.title)}</div>
      <h1>${escapeHtml(course.title)}</h1>
      <p class="course-subtitle">${escapeHtml(course.subtitle || '')}</p>
      <div class="course-band-rating">
        ${course.rating ? `<span class="rating-num" style="color:#e59819">${course.rating.toFixed(1)}</span>${ratingStars(course.rating)}<span>(${course.reviewCount.toLocaleString()} ratings)</span>` : ''}
        <span>${course.students ? course.students.toLocaleString() + ' students' : ''}</span>
      </div>
      <p class="course-band-meta">Created by <b>${escapeHtml(course.instructor)}</b> · ${course.lastUpdated} · ${course.language} · ${fmtTotal(courseTotalDuration(course))} total</p>
      ${course.bestSeller ? '<span class="bestseller-badge" style="position:static">Best seller</span>' : ''}
    </div>

    <div class="course-landing-grid">
      <div class="course-main">
        <div class="objectives-box">
          <h2>What you'll learn</h2>
          <div class="objectives-grid">${objectivesHtml}</div>
        </div>

        <div class="curriculum">
          <h2 class="section-title">Course content</h2>
          <p class="text-muted text-sm mb-2">${course.lessons.length} lectures · ${fmtTotal(courseTotalDuration(course))} total length</p>
          ${renderCurriculum(course)}
        </div>

        <div class="mt-2">
          <h2 class="section-title">Requirements</h2>
          <ul class="req-list">${requirementsHtml}</ul>
        </div>

        <div class="mt-2">
          <h2 class="section-title">Description</h2>
          <p style="font-size:0.95rem">${escapeHtml(course.description)}</p>
        </div>

        <div class="instructor-section">
          <div class="instructor-avatar">${escapeHtml(course.instructor.split(' ').map(w => w[0]).join('').slice(0, 2))}</div>
          <div>
            <h3 style="font-size:1.05rem;margin-bottom:0.15rem">${escapeHtml(course.instructor)}</h3>
            <p class="text-muted text-sm mb-2">${escapeHtml(course.instructorTitle || 'Instructor')}</p>
            <p class="text-muted text-sm">${course.rating ? `⭐ ${course.rating.toFixed(1)} instructor rating · ` : ''}${course.students ? course.students.toLocaleString() + ' students' : ''} · ${course.reviewCount.toLocaleString()} reviews</p>
          </div>
        </div>

        <div class="mt-2">
          <h2 class="section-title">Student reviews</h2>
          ${renderReviews(course)}
        </div>
      </div>

      <aside class="purchase-card">
        <div class="course-thumb-wrap ${previewEmbed && !owned ? 'has-preview' : ''}">
          ${heroContent}
          ${previewEmbed && !owned ? `<button class="preview-play" data-preview data-src="${previewEmbed}" aria-label="Preview this course">▶</button>` : ''}
        </div>
        <div class="purchase-card-body">
          ${priceRow(course, true)}
          ${discountPct(course) ? `<div class="discount-badge">${discountPct(course)}% off today only</div>` : ''}
          <div class="purchase-actions">
            ${actionHtml}
            ${previewEmbed && !owned ? `<button class="btn btn-outline-dark btn-block preview-btn" data-preview data-src="${previewEmbed}">▶ Preview this course</button>` : ''}
          </div>
          <p class="guarantee-note">30-Day Money-Back Guarantee</p>
          <h4 class="includes-title">This course includes</h4>
          <ul class="includes-list">${includesHtml}</ul>
          <button class="wish-btn-lg ${inWish ? 'active' : ''}" data-wishlist="${id}">${inWish ? '♥ Saved to Wishlist' : '♥ Save to Wishlist'}</button>
        </div>
      </aside>
    </div>

    <div class="preview-modal" id="preview-modal" hidden>
      <div class="preview-modal-backdrop" data-close-preview></div>
      <div class="preview-modal-content">
        <button class="preview-close" data-close-preview aria-label="Close preview">✕</button>
        <div class="video-wrapper">
          <iframe id="preview-frame" title="Course preview" allowfullscreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
        </div>
      </div>
    </div>`;
}

// ── Lesson player ──

function getCompletedLessons(courseId) {
  return state.completedLessons[courseId] || [];
}

function isLessonComplete(courseId, lessonIndex) {
  return getCompletedLessons(courseId).includes(lessonIndex);
}

function getCourseProgress(courseId) {
  const course = getCourse(courseId);
  if (!course || !course.lessons.length) return 0;
  return Math.round((getCompletedLessons(courseId).length / course.lessons.length) * 100);
}

function renderPurchaseGate(course) {
  return `
    <div class="purchase-gate">
      <div class="gate-lock">🔒</div>
      <h1 style="font-size:1.3rem;margin-bottom:0.5rem">${escapeHtml(course.title)}</h1>
      <p class="text-muted">This is a paid course. Purchase it to unlock all ${course.lessons.length} lectures.</p>
      <div class="gate-price">
        ${formatPrice(course.price)}
        ${course.originalPrice > course.price ? `<span class="original-price">${formatPrice(course.originalPrice)}</span>` : ''}
      </div>
      <div class="gate-actions">
        ${course.price <= 0
          ? `<button class="btn btn-primary" data-enroll="${course.id}">Enroll Free</button>`
          : `<button class="btn btn-primary" data-add-cart="${course.id}">Add to Cart</button>
             <button class="btn btn-dark" data-buy-now="${course.id}">Buy Now</button>`}
      </div>
      <a class="gate-back" href="/course/${course.id}" data-link>← Back to course details</a>
    </div>`;
}

function renderLesson({ id, index }) {
  const course = getCourse(id);
  if (!course) return `<div class="empty-state"><p>Course not found.</p></div>`;

  const lessonIndex = parseInt(index, 10);
  const lesson = course.lessons[lessonIndex];
  if (!lesson) return `<div class="empty-state"><p>Lesson not found.</p></div>`;

  if (!isPurchased(id)) {
    return renderPurchaseGate(course);
  }

  state.lastOpened = { courseId: id, lessonIndex };
  saveState();

  const prevIdx = lessonIndex > 0 ? lessonIndex - 1 : null;
  const nextIdx = lessonIndex < course.lessons.length - 1 ? lessonIndex + 1 : null;

  const sidebarItems = course.lessons.map((l, i) => `
    <div class="lesson-item ${i === lessonIndex ? 'active' : ''}" data-goto="/course/${id}/lesson/${i}">
      <span class="lesson-check ${isLessonComplete(id, i) ? 'done' : ''}">${isLessonComplete(id, i) ? '✓' : ''}</span>
      <span class="lesson-title">${escapeHtml(l.title)}</span>
      <span class="lesson-duration">${fmtClock(l.duration || 0)}</span>
    </div>`).join('');

  return `
    <div class="lesson-layout">
      <aside class="lesson-sidebar">
        <div class="lesson-sidebar-header">${escapeHtml(course.title)} · ${getCourseProgress(id)}%</div>
        ${sidebarItems}
      </aside>
      <div>
        <div class="lesson-nav">
          ${prevIdx !== null
            ? `<a class="btn btn-outline btn-sm" href="/course/${id}/lesson/${prevIdx}" data-link>← Previous</a>`
            : '<span></span>'}
          ${nextIdx !== null
            ? `<a class="btn btn-primary btn-sm" href="/course/${id}/lesson/${nextIdx}" data-link>Next: ${escapeHtml(course.lessons[nextIdx].title)} →</a>`
            : ''}
        </div>
        <h1 style="font-size:1.35rem;margin-bottom:1rem">${escapeHtml(lesson.title)}</h1>
        <div class="video-wrapper">
          <iframe src="${getEmbedUrl(lesson.videoId)}" allowfullscreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>
        </div>
        <div class="lesson-actions">
          <button class="btn btn-success" id="mark-complete" data-course="${id}" data-lesson="${lessonIndex}">
            ${isLessonComplete(id, lessonIndex) ? '✓ Completed' : 'Mark Complete ✓'}
          </button>
        </div>
        <div class="ai-section">
          <h3>AI Lesson Notes</h3>
          <button class="btn btn-primary btn-sm" id="generate-notes" data-lesson="${escapeHtml(lesson.title)}" data-course="${escapeHtml(course.title)}">Generate Notes</button>
          <div id="notes-content" class="ai-content mt-2"></div>
        </div>
        <div class="ai-section">
          <h3>Test Yourself</h3>
          <button class="btn btn-accent btn-sm" id="generate-quiz" data-lesson="${escapeHtml(lesson.title)}">Start Quiz</button>
          <div id="quiz-content" class="mt-2"></div>
        </div>
      </div>
    </div>`;
}

// ── Cart ──

function renderCart() {
  const items = state.cart.map(id => getCourse(id)).filter(Boolean);
  if (!items.length) {
    return `<div class="empty-state cart-empty">
      <p>Your cart is empty.</p>
      <a href="/library" class="btn btn-primary" data-link>Browse Courses</a>
    </div>`;
  }
  const total = cartSubtotal();
  const original = cartOriginalTotal();
  const savings = cartSavings();

  const rows = items.map(course => `
    <div class="cart-item">
      <div class="cart-item-thumb">${renderThumbnail(course, 'course-thumb')}</div>
      <div class="cart-item-info">
        <h3>${escapeHtml(course.title)}</h3>
        <div class="text-muted text-sm">By ${escapeHtml(course.instructor)}</div>
        <div class="cart-item-meta text-sm text-muted">${course.lessons.length} lectures · ${fmtTotal(courseTotalDuration(course))}</div>
        <button class="cart-remove" data-remove-cart="${course.id}">Remove</button>
      </div>
      <div class="cart-item-price">
        <span class="price">${formatPrice(course.price)}</span>
        ${course.originalPrice > course.price ? `<div class="original-price">${formatPrice(course.originalPrice)}</div>` : ''}
      </div>
    </div>`).join('');

  return `
    <div class="page-header">
      <h1>Shopping Cart</h1>
      <p>${items.length} course${items.length > 1 ? 's' : ''} in your cart</p>
    </div>
    <div class="cart-layout">
      <div class="cart-items">${rows}</div>
      <aside class="cart-summary">
        <h3 class="mb-2">Summary</h3>
        <div class="summary-row"><span>Original price:</span><span>${formatPrice(original)}</span></div>
        <div class="summary-row"><span>Discount:</span><span class="savings">−${formatPrice(savings)}</span></div>
        <div class="summary-total"><span>Total:</span><span class="price">${formatPrice(total)}</span></div>
        <button class="btn btn-primary btn-block mt-2" data-goto="/checkout">Checkout →</button>
        <p class="guarantee-note mt-2">30-Day Money-Back Guarantee · Secure demo checkout</p>
      </aside>
    </div>`;
}

// ── Checkout ──

function luhnCheck(num) {
  let sum = 0;
  let alt = false;
  for (let i = num.length - 1; i >= 0; i--) {
    let d = parseInt(num[i], 10);
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

function cardBrand(firstDigit) {
  if (firstDigit === '4') return 'Visa';
  if (firstDigit === '5') return 'Mastercard';
  if (firstDigit === '3') return 'Amex';
  if (firstDigit === '6') return 'Discover';
  return 'Card';
}

function renderCheckout() {
  const items = state.cart.map(id => getCourse(id)).filter(Boolean);
  if (!items.length) {
    return `<div class="empty-state cart-empty">
      <p>Nothing to check out — your cart is empty.</p>
      <a href="/library" class="btn btn-primary" data-link>Browse Courses</a>
    </div>`;
  }
  const total = cartSubtotal();
  const original = cartOriginalTotal();

  const orderItems = items.map(course => `
    <div class="order-item">
      ${renderThumbnail(course, 'course-thumb')}
      <span class="oi-title">${escapeHtml(course.title)}</span>
      <span class="oi-price">${formatPrice(course.price)}</span>
    </div>`).join('');

  return `
    <div class="page-header">
      <h1>Checkout</h1>
      <p>Secure demo checkout — no real money is charged</p>
    </div>
    <div class="checkout-layout">
      <form id="checkout-form" class="checkout-form" novalidate>
        <h2 class="mb-2" style="font-size:1.2rem">Payment Details</h2>
        <div class="card-brand-row">
          <span class="card-brand active">💳 Card</span>
          <span class="card-brand">PayPal (coming soon)</span>
        </div>
        <div class="form-group">
          <label for="pay-name">Name on card *</label>
          <input type="text" id="pay-name" placeholder="Alex Learner" autocomplete="off" />
        </div>
        <div class="form-group">
          <label for="pay-number">Card number *</label>
          <input type="text" id="pay-number" placeholder="4242 4242 4242 4242" inputmode="numeric" autocomplete="off" maxlength="19" />
        </div>
        <div class="checkout-card-fields">
          <div class="form-group">
            <label for="pay-expiry">Expiry *</label>
            <input type="text" id="pay-expiry" placeholder="MM/YY" inputmode="numeric" autocomplete="off" maxlength="5" />
          </div>
          <div class="form-group">
            <label for="pay-cvv">CVV *</label>
            <input type="text" id="pay-cvv" placeholder="123" inputmode="numeric" autocomplete="off" maxlength="4" />
          </div>
        </div>
        <div class="pay-note">🔒 This is a demo. Your card is validated locally and no real payment is processed. Try card 4242 4242 4242 4242.</div>
      </form>

      <aside class="order-summary">
        <h3 class="mb-2">Order Summary</h3>
        ${orderItems}
        <div class="summary-row mt-2"><span>Original price:</span><span>${formatPrice(original)}</span></div>
        <div class="summary-row"><span>Discount:</span><span class="savings">−${formatPrice(Math.max(0, original - total))}</span></div>
        <div class="summary-total"><span>Total:</span><span class="price">${formatPrice(total)}</span></div>
        <button type="submit" form="checkout-form" class="btn btn-primary btn-block mt-2" id="pay-btn">Complete Payment</button>
        <p class="guarantee-note mt-2">30-Day Money-Back Guarantee</p>
      </aside>
    </div>`;
}

// ── Order success ──

function renderSuccess() {
  const order = state.orders[state.orders.length - 1];
  if (!order) return `<div class="empty-state"><p>No recent order found.</p><a href="/library" class="btn btn-primary" data-link>Browse Courses</a></div>`;

  const confetti = Array.from({ length: 18 }, (_, i) =>
    `<span style="left:${(i * 5.5 + 4) % 100}%;animation-duration:${1.2 + (i % 5) * 0.3}s;animation-delay:${(i % 7) * 0.08}s;background:hsl(${i * 22},70%,55%)"></span>`
  ).join('');

  const items = order.items.map(id => {
    const c = getCourse(id);
    return c ? `<div class="success-item">✓ ${escapeHtml(c.title)}</div>` : '';
  }).join('');

  return `
    <div class="success-page">
      <div class="confetti">${confetti}</div>
      <div class="success-check">✓</div>
      <h1>Payment Successful!</h1>
      <p class="text-muted">Your courses are ready to learn. Receipt sent to your account.</p>
      <div class="success-order">
        <div class="row"><span>Order number</span><b>${order.id}</b></div>
        <div class="row"><span>Date</span><b>${new Date(order.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</b></div>
        <div class="row"><span>Paid with</span><b>${order.method}</b></div>
        <div class="row"><span>Total</span><b class="price">${formatPrice(order.total)}</b></div>
      </div>
      <h2 class="section-title">Your courses</h2>
      <div class="success-items">${items}</div>
      <div class="success-actions">
        <a href="/my-courses" class="btn btn-primary" data-link>Start Learning →</a>
        <a href="/library" class="btn btn-outline" data-link>Browse More</a>
      </div>
    </div>`;
}

// ── My Learning ──

function renderMyCourses() {
  const owned = state.purchases.map(id => getCourse(id)).filter(Boolean);
  const lessonsDone = Object.values(state.completedLessons).reduce((sum, arr) => sum + arr.length, 0);
  const totalSpent = state.orders.reduce((sum, o) => sum + o.total, 0);

  const continueHtml = state.lastOpened && getCourse(state.lastOpened.courseId)
    ? `<div class="continue-card">
        <div>
          <h2>Continue Learning</h2>
          <p>${escapeHtml(getCourse(state.lastOpened.courseId).title)} — ${escapeHtml(getCourse(state.lastOpened.courseId).lessons[state.lastOpened.lessonIndex]?.title || 'Next lesson')}</p>
        </div>
        <a href="/course/${state.lastOpened.courseId}/lesson/${state.lastOpened.lessonIndex}" class="btn" data-link>Resume →</a>
      </div>`
    : '';

  const grid = owned.length
    ? owned.map(course => {
        const progress = getCourseProgress(course.id);
        return `
          <div class="my-course-card" data-goto="/course/${course.id}">
            <div class="course-thumb-wrap">
              ${renderThumbnail(course, 'course-thumb')}
            </div>
            <div class="my-course-card-body">
              <h3 class="course-card-title">${escapeHtml(course.title)}</h3>
              <div class="progress-text text-sm text-muted">${progress}% complete · ${getCompletedLessons(course.id).length}/${course.lessons.length} lectures</div>
              <div class="progress-bar"><div class="progress-fill" style="width:${progress}%"></div></div>
              <div class="mt-2">
                <a href="/course/${course.id}/lesson/0" class="btn btn-primary btn-sm" data-link>Continue →</a>
              </div>
            </div>
          </div>`;
      }).join('')
    : `<div class="empty-state"><p>You haven't purchased any courses yet.</p><a href="/library" class="btn btn-primary" data-link>Browse Library</a></div>`;

  const ordersHtml = state.orders.length
    ? `<table class="orders-table">
        <thead><tr><th>Order</th><th>Date</th><th>Payment</th><th>Total</th></tr></thead>
        <tbody>
          ${state.orders.slice().reverse().map(o => `
            <tr>
              <td><b>${o.id}</b></td>
              <td>${new Date(o.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</td>
              <td>${o.method}</td>
              <td><b>${formatPrice(o.total)}</b></td>
            </tr>`).join('')}
        </tbody>
      </table>`
    : '<p class="text-muted">No orders yet.</p>';

  return `
    <div class="page-header">
      <h1>My Learning</h1>
      <p>${greeting()}, ${state.user.name} — here's your progress</p>
    </div>
    <div class="stats-row">
      <div class="stat-card"><div class="stat-value">${owned.length}</div><div class="stat-label">Courses Purchased</div></div>
      <div class="stat-card"><div class="stat-value">${lessonsDone}</div><div class="stat-label">Lessons Completed</div></div>
      <div class="stat-card"><div class="stat-value">${formatPrice(totalSpent)}</div><div class="stat-label">Total Invested</div></div>
      <div class="stat-card"><div class="stat-value">${state.user.streak}</div><div class="stat-label">Day Streak</div></div>
    </div>
    ${continueHtml}
    <h2 class="section-title">My Courses</h2>
    <div class="my-course-grid">${grid}</div>
    <h2 class="section-title mt-2">Order History</h2>
    ${ordersHtml}`;
}

// ── Wishlist ──

function renderWishlist() {
  const items = state.wishlist.map(id => getCourse(id)).filter(Boolean);
  return `
    <div class="page-header">
      <h1>Wishlist</h1>
      <p>Courses you've saved for later</p>
    </div>
    ${items.length
      ? `<div class="course-grid">${items.map(courseCard).join('')}</div>`
      : `<div class="empty-state"><p>Your wishlist is empty.</p><a href="/library" class="btn btn-primary" data-link>Discover Courses</a></div>`}`;
}

// ── Profile ──

function renderProfile() {
  const lessonsDone = Object.values(state.completedLessons).reduce((sum, arr) => sum + arr.length, 0);
  const totalSpent = state.orders.reduce((sum, o) => sum + o.total, 0);
  const completed = state.purchases.filter(id => getCourseProgress(id) === 100);
  const achievements = [
    { id: 'first-lesson', icon: '🎯', label: 'First Lesson', unlocked: lessonsDone >= 1 },
    { id: 'enrolled', icon: '📚', label: 'First Purchase', unlocked: state.purchases.length >= 1 },
    { id: 'streak', icon: '🔥', label: '5-Day Streak', unlocked: state.user.streak >= 5 },
    { id: 'quiz', icon: '🏆', label: 'Quiz Master', unlocked: lessonsDone >= 3 }
  ];
  const achievementsHtml = achievements.map(a =>
    `<div class="achievement ${a.unlocked ? 'unlocked' : ''}"><span class="achievement-icon">${a.icon}</span>${a.label}</div>`
  ).join('');
  const completedHtml = completed.length
    ? completed.map(id => {
        const c = getCourse(id);
        return `<li><span>${escapeHtml(c.title)}</span><span class="text-muted text-sm">100%</span></li>`;
      }).join('')
    : '<li class="text-muted">No completed courses yet</li>';

  return `
    <div class="profile-header">
      <div class="profile-avatar">AL</div>
      <div>
        <h1>${escapeHtml(state.user.name)}</h1>
        <p class="text-muted">Member since ${state.user.memberSince} · ${state.purchases.length} courses owned</p>
      </div>
    </div>
    <div class="profile-stats">
      <div class="stat-card"><div class="stat-value">${state.purchases.length}</div><div class="stat-label">Courses Purchased</div></div>
      <div class="stat-card"><div class="stat-value">${lessonsDone}</div><div class="stat-label">Lessons Done</div></div>
      <div class="stat-card"><div class="stat-value">${formatPrice(totalSpent)}</div><div class="stat-label">Total Invested</div></div>
    </div>
    <h2 class="section-title">Completed Courses</h2>
    <ul class="completed-list mb-2">${completedHtml}</ul>
    <h2 class="section-title">Achievements</h2>
    <div class="achievements">${achievementsHtml}</div>`;
}

// ── Add course ──

function renderAddCourse() {
  return `
    <div class="page-header">
      <h1>Create a Course</h1>
      <p>Publish to the Elevora marketplace — free courses enroll instantly</p>
    </div>
    <div class="add-course-layout">
      <form id="add-course-form" class="card card-static">
        <div class="form-group">
          <label for="course-title">Course Title *</label>
          <input type="text" id="course-title" required placeholder="e.g. React Fundamentals" />
        </div>
        <div class="form-group">
          <label for="course-category">Category *</label>
          <select id="course-category" required>
            <option value="">Select category</option>
            <option value="Code">Code</option>
            <option value="Design">Design</option>
            <option value="Business">Business</option>
            <option value="Science">Science</option>
          </select>
        </div>
        <div class="form-group">
          <label for="course-difficulty">Level *</label>
          <select id="course-difficulty" required>
            <option value="">Select level</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>
        </div>
        <div class="form-group">
          <label for="course-instructor">Instructor Name *</label>
          <input type="text" id="course-instructor" required placeholder="Instructor name" />
        </div>
        <div class="form-group">
          <label for="course-price">Price (USD) — leave 0 for a free course</label>
          <input type="number" id="course-price" min="0" step="0.01" value="0" />
        </div>
        <div class="form-group">
          <label for="course-description">Description *</label>
          <textarea id="course-description" required placeholder="Describe the course…"></textarea>
        </div>
        <div class="form-group">
          <label for="course-thumbnail">Thumbnail URL (optional)</label>
          <input type="url" id="course-thumbnail" placeholder="https://…" />
        </div>
        <label style="font-weight:600;font-size:0.85rem">Lessons *</label>
        <div class="lesson-rows" id="lesson-rows">
          <div class="lesson-row">
            <input type="text" class="lesson-title-input" placeholder="Lesson Title" required />
            <input type="text" class="lesson-url-input" placeholder="YouTube URL" required />
            <button type="button" class="btn btn-outline btn-sm remove-lesson" disabled>✕</button>
          </div>
        </div>
        <button type="button" class="btn btn-outline btn-sm mb-2" id="add-lesson-row">+ Add Lesson</button>
        <button type="submit" class="btn btn-primary">Publish Course</button>
      </form>
      <div class="preview-panel">
        <h3>Live Preview</h3>
        <div class="course-card" id="preview-card">
          <div class="course-thumb"><div class="course-thumb-gradient" style="${gradientFallback('New Course').style}">NC</div></div>
          <div class="course-card-body">
            <h3 id="preview-title">New Course</h3>
            <div class="course-meta" id="preview-meta">Instructor · 1 lesson</div>
            <div class="course-price-row" id="preview-price"><span class="price-free">Free</span></div>
            <span class="badge badge-beginner" id="preview-badge">Beginner</span>
          </div>
        </div>
      </div>
    </div>`;
}

// ── AI Tutor ──

function renderTutor() {
  const messagesHtml = state.tutorMessages.length
    ? state.tutorMessages.map(m =>
        `<div class="message message-${m.role === 'user' ? 'user' : 'ai'}">${m.role === 'user' ? escapeHtml(m.content) : formatAiContent(m.content)}</div>`
      ).join('')
    : `<div class="empty-state" style="padding:2rem"><p>Ask me anything about your courses! 🤖</p></div>`;

  return `
    <div class="page-header">
      <h1>AI Tutor</h1>
      <p>Your personal learning assistant</p>
    </div>
    <div class="tutor-page">
      <div class="tutor-messages" id="tutor-messages">${messagesHtml}</div>
      <div class="tutor-chips" id="tutor-chips">
        <span class="tutor-chips-label">Try:</span>
        <button class="tutor-chip" data-tutor-prompt="Explain how closures work in JavaScript">Explain closures</button>
        <button class="tutor-chip" data-tutor-prompt="What is the difference between var and let?">var vs let</button>
        <button class="tutor-chip" data-tutor-prompt="Give me an example of a Python list comprehension">Python example</button>
        <button class="tutor-chip" data-tutor-prompt="Quiz me on machine learning">Quiz me 🤓</button>
      </div>
      <div class="tutor-input-bar">
        <input type="text" id="tutor-input" placeholder="Ask a question…" autocomplete="off" />
        <button class="btn btn-primary" id="tutor-send">Send</button>
      </div>
    </div>`;
}

// ── Event binding ──

function bindEvents(path, params) {
  updateCartBadge();

  document.querySelectorAll('[data-goto]').forEach(el => {
    el.addEventListener('click', () => navigate(el.dataset.goto));
  });

  document.querySelectorAll('[data-enroll]').forEach(btn => {
    btn.addEventListener('click', () => {
      const courseId = btn.dataset.enroll;
      const course = getCourse(courseId);
      if (!course) return;
      if (course.price > 0) {
        addToCart(courseId);
        return;
      }
      if (!isPurchased(courseId)) {
        state.purchases.push(courseId);
        saveState();
        showToast('Enrolled successfully! 🎉');
      }
      navigate(`/course/${courseId}`);
    });
  });

  document.querySelectorAll('[data-add-cart]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.addCart;
      if (isPurchased(id)) {
        navigate(`/course/${id}`);
        return;
      }
      addToCart(id);
      // Refresh current view so "In Cart" states stay consistent.
      navigate(path, false);
    });
  });

  document.querySelectorAll('[data-buy-now]').forEach(btn => {
    btn.addEventListener('click', () => buyNow(btn.dataset.buyNow));
  });

  document.querySelectorAll('[data-wishlist]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      toggleWishlist(btn.dataset.wishlist);
      if (path === '/wishlist') {
        navigate(path, false);
        return;
      }
      const nowInWish = inWishlist(btn.dataset.wishlist);
      btn.classList.toggle('active', nowInWish);
      btn.title = nowInWish ? 'Remove from wishlist' : 'Save to wishlist';
      if (btn.classList.contains('wish-btn-lg')) {
        btn.textContent = nowInWish ? '♥ Saved to Wishlist' : '♥ Save to Wishlist';
      }
    });
  });

  document.querySelectorAll('[data-remove-cart]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.cart = state.cart.filter(id => id !== btn.dataset.removeCart);
      saveState();
      updateCartBadge();
      navigate(path, false);
      showToast('Removed from cart');
    });
  });

  // Home hero search + chips + category tiles
  if (path === '/') {
    const runSearch = term => {
      state.librarySearch = term;
      navigate('/library');
    };
    document.getElementById('home-search')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') runSearch(e.target.value.trim());
    });
    document.getElementById('home-search-btn')?.addEventListener('click', () => {
      runSearch(document.getElementById('home-search')?.value.trim() || '');
    });
    document.querySelectorAll('[data-search]').forEach(chip => {
      chip.addEventListener('click', () => runSearch(chip.dataset.search));
    });
    document.querySelectorAll('[data-category]').forEach(tile => {
      tile.addEventListener('click', () => {
        state.libraryFilter = tile.dataset.category;
        navigate('/library');
      });
    });
  }

  if (path === '/library') {
    const search = document.getElementById('library-search');
    if (search) {
      search.addEventListener('input', e => {
        state.librarySearch = e.target.value;
        document.getElementById('app').innerHTML = renderLibrary();
        bindEvents('/library', {});
        const input = document.getElementById('library-search');
        if (input) {
          input.focus();
          input.setSelectionRange(input.value.length, input.value.length);
        }
      });
    }
    document.getElementById('library-sort')?.addEventListener('change', e => {
      state.librarySort = e.target.value;
      document.getElementById('app').innerHTML = renderLibrary();
      bindEvents('/library', {});
    });
    document.querySelectorAll('[data-filter]').forEach(tab => {
      tab.addEventListener('click', () => {
        state.libraryFilter = tab.dataset.filter;
        document.getElementById('app').innerHTML = renderLibrary();
        bindEvents('/library', {});
      });
    });
  }

  if (path === '/course/:id' || (path.startsWith('/course/') && !path.includes('/lesson/'))) {
    document.querySelectorAll('[data-toggle-module]').forEach(header => {
      header.addEventListener('click', () => {
        header.closest('.module').classList.toggle('open');
      });
    });

    const modal = document.getElementById('preview-modal');
    const frame = document.getElementById('preview-frame');
    if (modal && frame) {
      document.querySelectorAll('[data-preview]').forEach(el => {
        el.addEventListener('click', e => {
          e.stopPropagation();
          frame.src = el.dataset.src || '';
          modal.hidden = false;
          document.body.style.overflow = 'hidden';
        });
      });
      document.querySelectorAll('[data-close-preview]').forEach(el => {
        el.addEventListener('click', closePreviewModal);
      });
    }
  }

  if (path.startsWith('/course/') && path.includes('/lesson/')) {
    const markBtn = document.getElementById('mark-complete');
    if (markBtn) {
      markBtn.addEventListener('click', () => {
        const courseId = markBtn.dataset.course;
        const lessonIdx = parseInt(markBtn.dataset.lesson, 10);
        if (!state.completedLessons[courseId]) state.completedLessons[courseId] = [];
        if (!state.completedLessons[courseId].includes(lessonIdx)) {
          state.completedLessons[courseId].push(lessonIdx);
          state.user.hoursLearned += 1;
          saveState();
          showToast('Lesson marked complete! 🎉');
        }
        navigate(path, false);
      });
    }

    const notesBtn = document.getElementById('generate-notes');
    if (notesBtn) {
      notesBtn.addEventListener('click', async () => {
        const container = document.getElementById('notes-content');
        notesBtn.disabled = true;
        showSkeleton(container);
        try {
          const html = await api.generateLessonNotes(notesBtn.dataset.lesson, notesBtn.dataset.course);
          container.innerHTML = html;
        } catch (err) {
          container.innerHTML = `<p class="text-muted">Failed to generate notes: ${escapeHtml(err.message)}</p>`;
          showToast('Failed to generate notes', 'error');
        }
        notesBtn.disabled = false;
      });
    }

    const quizBtn = document.getElementById('generate-quiz');
    if (quizBtn) {
      quizBtn.addEventListener('click', async () => {
        const container = document.getElementById('quiz-content');
        quizBtn.disabled = true;
        showSkeleton(container, 3);
        try {
          const questions = await api.generateQuiz(quizBtn.dataset.lesson);
          container.innerHTML = questions.map((q, qi) => `
            <div class="quiz-card" data-quiz="${qi}">
              <p>${qi + 1}. ${escapeHtml(q.question)}</p>
              <div class="quiz-options">
                ${q.options.map(opt => `
                  <button class="quiz-option" data-answer="${escapeHtml(q.answer)}" data-choice="${escapeHtml(opt)}">${escapeHtml(opt)}</button>
                `).join('')}
              </div>
            </div>`).join('');

          container.querySelectorAll('.quiz-option').forEach(opt => {
            opt.addEventListener('click', () => {
              const card = opt.closest('.quiz-card');
              if (card.dataset.answered) return;
              card.dataset.answered = 'true';
              const correct = opt.dataset.answer;
              card.querySelectorAll('.quiz-option').forEach(o => {
                o.classList.add('disabled');
                if (o.dataset.choice === correct) o.classList.add('correct');
                else if (o === opt && o.dataset.choice !== correct) o.classList.add('wrong');
              });
            });
          });
        } catch (err) {
          container.innerHTML = `<p class="text-muted">Failed to generate quiz: ${escapeHtml(err.message)}</p>`;
          showToast('Failed to generate quiz', 'error');
        }
        quizBtn.disabled = false;
      });
    }
  }

  if (path === '/checkout') {
    const formatCard = v => v.replace(/\D/g, '').slice(0, 16).replace(/(\d{4})(?=\d)/g, '$1 ');
    const formatExpiry = v => {
      const d = v.replace(/\D/g, '').slice(0, 4);
      if (d.length <= 2) return d;
      return d.slice(0, 2) + '/' + d.slice(2);
    };

    const num = document.getElementById('pay-number');
    num?.addEventListener('input', () => { num.value = formatCard(num.value); });
    const exp = document.getElementById('pay-expiry');
    exp?.addEventListener('input', () => { exp.value = formatExpiry(exp.value); });
    const cvv = document.getElementById('pay-cvv');
    cvv?.addEventListener('input', () => { cvv.value = cvv.value.replace(/\D/g, '').slice(0, 4); });

    document.getElementById('checkout-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const payBtn = document.getElementById('pay-btn');
      if (payBtn?.disabled) return; // prevent duplicate orders while processing
      const name = document.getElementById('pay-name').value.trim();
      const number = num.value.replace(/\s/g, '');
      const expiry = exp.value;
      const cvvVal = cvv.value;

      const showError = msg => showToast(msg, 'error');
      if (!name) return showError('Please enter the name on the card');
      if (number.length < 15 || !luhnCheck(number)) return showError('Please enter a valid card number (try 4242 4242 4242 4242)');
      const expMatch = expiry.match(/^(\d{2})\/(\d{2})$/);
      if (!expMatch) return showError('Expiry must be in MM/YY format');
      const month = parseInt(expMatch[1], 10);
      const year = 2000 + parseInt(expMatch[2], 10);
      if (month < 1 || month > 12) return showError('Invalid expiry month');
      const now = new Date();
      if (year < now.getFullYear() || (year === now.getFullYear() && month < now.getMonth() + 1)) {
        return showError('Card has expired');
      }
      if (cvvVal.length < 3) return showError('Enter a valid CVV');

      // Simulate payment processing.
      payBtn.disabled = true;

      payBtn.innerHTML = '<span class="spinner"></span> Processing…';
      setTimeout(() => {
        const order = {
          id: 'ELE-' + Math.random().toString(36).slice(2, 8).toUpperCase(),
          date: new Date().toISOString(),
          items: [...state.cart],
          total: cartSubtotal(),
          method: `${cardBrand(number[0])} •••• ${number.slice(-4)}`
        };
        state.orders.push(order);
        state.purchases.push(...state.cart);
        state.cart = [];
        saveState();
        updateCartBadge();
        navigate('/checkout/success');
      }, 1600);
    });
  }

  if (path === '/add-course') {
    const titleInput = document.getElementById('course-title');
    const updatePreview = () => {
      const title = titleInput?.value || 'New Course';
      const instructor = document.getElementById('course-instructor')?.value || 'Instructor';
      const difficulty = document.getElementById('course-difficulty')?.value || 'Beginner';
      const price = parseFloat(document.getElementById('course-price')?.value) || 0;
      const rows = document.querySelectorAll('.lesson-row').length;
      document.getElementById('preview-title').textContent = title;
      document.getElementById('preview-meta').textContent = `${instructor} · ${rows} lesson${rows !== 1 ? 's' : ''}`;
      document.getElementById('preview-price').innerHTML = price > 0
        ? `<span class="price">$${price.toFixed(2)}</span>`
        : '<span class="price-free">Free</span>';
      const badge = document.getElementById('preview-badge');
      badge.textContent = difficulty;
      badge.className = `badge badge-${difficulty.toLowerCase()}`;
      const fb = gradientFallback(title);
      const grad = document.querySelector('#preview-card .course-thumb-gradient');
      if (grad) {
        grad.style.cssText = fb.style;
        grad.textContent = fb.initials;
      }
    };

    ['course-title', 'course-instructor', 'course-difficulty', 'course-price'].forEach(id => {
      document.getElementById(id)?.addEventListener('input', updatePreview);
      document.getElementById(id)?.addEventListener('change', updatePreview);
    });

    document.getElementById('add-lesson-row')?.addEventListener('click', () => {
      const rows = document.getElementById('lesson-rows');
      const row = document.createElement('div');
      row.className = 'lesson-row';
      row.innerHTML = `
        <input type="text" class="lesson-title-input" placeholder="Lesson Title" required />
        <input type="text" class="lesson-url-input" placeholder="YouTube URL" required />
        <button type="button" class="btn btn-outline btn-sm remove-lesson">✕</button>`;
      rows.appendChild(row);
      bindRemoveLesson();
      updatePreview();
    });

    function bindRemoveLesson() {
      document.querySelectorAll('.remove-lesson').forEach(btn => {
        btn.onclick = () => {
          const rows = document.querySelectorAll('.lesson-row');
          if (rows.length > 1) {
            btn.closest('.lesson-row').remove();
            document.querySelector('.remove-lesson').disabled = document.querySelectorAll('.lesson-row').length <= 1;
            updatePreview();
          }
        };
      });
      const removeBtns = document.querySelectorAll('.remove-lesson');
      removeBtns.forEach(b => { b.disabled = removeBtns.length <= 1; });
    }
    bindRemoveLesson();

    document.getElementById('add-course-form')?.addEventListener('submit', e => {
      e.preventDefault();
      const title = document.getElementById('course-title').value.trim();
      const category = document.getElementById('course-category').value;
      const difficulty = document.getElementById('course-difficulty').value;
      const instructor = document.getElementById('course-instructor').value.trim();
      const price = Math.max(0, parseFloat(document.getElementById('course-price').value) || 0);
      const description = document.getElementById('course-description').value.trim();
      const thumbnail = document.getElementById('course-thumbnail').value.trim() || null;

      const lessonRows = document.querySelectorAll('.lesson-row');
      const lessons = [];
      for (const row of lessonRows) {
        const lt = row.querySelector('.lesson-title-input').value.trim();
        const url = row.querySelector('.lesson-url-input').value.trim();
        const videoId = extractVideoId(url);
        if (!lt || !videoId) {
          showToast('Each lesson needs a title and valid YouTube URL', 'error');
          return;
        }
        lessons.push({ title: lt, videoId, duration: 600 });
      }

      if (!title || !category || !difficulty || !instructor || !description) {
        showToast('Please fill in all required fields', 'error');
        return;
      }

      let id = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      if (getCourse(id)) id = `${id}-${Date.now()}`;

      const newCourse = {
        id,
        title,
        category,
        difficulty,
        instructor,
        instructorTitle: 'Instructor',
        description,
        thumbnail,
        price,
        originalPrice: 0,
        rating: 0,
        reviewCount: 0,
        students: 1,
        bestSeller: false,
        hotAndNew: true,
        language: 'English',
        lastUpdated: 'July 2026',
        lessons,
        userAdded: true
      };

      state.courses.push(newCourse);
      saveState();
      showToast('Course published successfully!');
      navigate(`/course/${id}`);
    });
  }

  if (path === '/tutor') {
    const renderMessages = () => state.tutorMessages.map(m =>
      `<div class="message message-${m.role === 'user' ? 'user' : 'ai'}">${m.role === 'user' ? escapeHtml(m.content) : formatAiContent(m.content)}</div>`
    ).join('');

    const send = async () => {
      const input = document.getElementById('tutor-input');
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      state.tutorMessages.push({ role: 'user', content: text });
      saveState();
      const container = document.getElementById('tutor-messages');
      container.innerHTML = renderMessages() + '<div class="message message-ai skeleton" style="height:44px;width:60%"></div>';
      container.scrollTop = container.scrollHeight;

      try {
        const apiMessages = state.tutorMessages.map(m => ({ role: m.role, content: m.content }));
        const ownedTitles = state.purchases.map(id => getCourse(id)?.title).filter(Boolean);
        const reply = await api.tutorChat(apiMessages, ownedTitles);
        state.tutorMessages.push({ role: 'assistant', content: reply });
        saveState();
        container.innerHTML = renderMessages();
        container.scrollTop = container.scrollHeight;
      } catch (err) {
        container.querySelector('.skeleton')?.remove();
        state.tutorMessages.pop(); // drop the unsent user message
        saveState();
        container.innerHTML = renderMessages();
        input.value = text; // give the question back so nothing is lost
        input.focus();
        showToast('Failed to get response', 'error');
      }
    };

    document.getElementById('tutor-send')?.addEventListener('click', send);
    document.getElementById('tutor-input')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') send();
    });
    document.querySelectorAll('[data-tutor-prompt]').forEach(chip => {
      chip.addEventListener('click', () => {
        const input = document.getElementById('tutor-input');
        if (input) input.value = chip.dataset.tutorPrompt;
        send();
      });
    });

    const container = document.getElementById('tutor-messages');
    if (container) container.scrollTop = container.scrollHeight;
  }
}

// ── Init ──

function init() {
  loadState();

  registerRoute('/', () => renderHome());
  registerRoute('/library', () => renderLibrary());
  registerRoute('/course/:id', params => renderCourseDetail(params));
  registerRoute('/course/:id/lesson/:index', params => renderLesson(params));
  registerRoute('/cart', () => renderCart());
  registerRoute('/checkout', () => renderCheckout());
  registerRoute('/checkout/success', () => renderSuccess());
  registerRoute('/my-courses', () => renderMyCourses());
  registerRoute('/wishlist', () => renderWishlist());
  registerRoute('/add-course', () => renderAddCourse());
  registerRoute('/tutor', () => renderTutor());
  registerRoute('/profile', () => renderProfile());

  setRouteChangeCallback((path, params) => {
    document.body.style.overflow = ''; // release scroll lock if a preview modal was open
    const navSearch = document.getElementById('nav-search');
    if (navSearch) navSearch.value = state.librarySearch || '';
    bindEvents(path, params);
  });

  document.addEventListener('click', e => {
    const link = e.target.closest('[data-link]');
    if (link) {
      e.preventDefault();
      navigate(link.getAttribute('href'));
      document.getElementById('nav-links')?.classList.remove('open');
    }
  });

  document.getElementById('hamburger')?.addEventListener('click', () => {
    document.getElementById('nav-links')?.classList.toggle('open');
  });

  const navSearch = document.getElementById('nav-search');
  navSearch?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      state.librarySearch = e.target.value.trim();
      navigate('/library');
      e.target.blur();
    }
  });

  // Theme toggle (light / dark) — persisted in localStorage.
  const themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) {
    const syncThemeBtn = () => {
      const dark = document.documentElement.getAttribute('data-theme') === 'dark';
      themeBtn.textContent = dark ? '☀️' : '🌙';
      themeBtn.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
    };
    syncThemeBtn();
    themeBtn.addEventListener('click', () => {
      const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('elevora_theme', next); } catch (e) { /* ignore */ }
      syncThemeBtn();
      showToast(next === 'dark' ? 'Dark mode on 🌙' : 'Light mode on ☀️');
    });
  }

  // Escape closes the course preview modal.
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closePreviewModal();
  });

  initRouter();
}

init();
