# Elevora — Run Guide

The actual web app lives in the **parent** directory of this Freebuff data folder:
`C:\Users\shaik\OneDrive\elevora lms` (contains `index.html`, `css/`, `js/`, `server.js`,
`package.json`, `node_modules`, `.env`). This `.freebuff` folder only holds Freebuff's
own databases — the server must be run from the app root, not from here.

## Reproduce uncommitted artifacts

1. **Install dependencies** (only if `node_modules` is missing):
   ```
   cd "C:\Users\shaik\OneDrive\elevora lms"
   npm install
   ```
   `package.json` deps: `express`, `cors`, `node-fetch`, `dotenv`.

2. **Copy `.env` from the main checkout** (git-ignored, holds the `ANTHROPIC_API_KEY`
   used by `POST /api/chat`). Never commit it:
   ```
   cp "C:\Users\shaik\OneDrive\elevora lms\.env" .env   # if missing
   ```
   The app still runs without it, but the AI Tutor chat endpoint returns
   `ANTHROPIC_API_KEY not configured` (500) until it is present.

## Run the server

```
cd "C:\Users\shaik\OneDrive\elevora lms"
node server.js          # or: npm start   (dev: npm run dev / nodemon)
```

- Default port is **3001** (`PORT` env overrides). Note: on this machine 3001 may be
  occupied by Docker's backend (`com.docker.backend`), in which case use e.g.:
  ```
  PORT=3000 node server.js
  ```
- Server serves the static site from its own directory and proxies
  `POST /api/chat` to the Anthropic API.
- Confirm it is up: `curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/` → `200`.

### Detached launch (PowerShell)

```powershell
$env:PORT='3000'
$p = Start-Process -FilePath 'node' -ArgumentList 'server.js' `
  -WorkingDirectory 'C:\Users\shaik\OneDrive\elevora lms' `
  -RedirectStandardOutput '<log>.log' -RedirectStandardError '<log>.err.log' `
  -PassThru -WindowStyle Hidden
Write-Output $p.Id
```
